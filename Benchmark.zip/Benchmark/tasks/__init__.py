from .task import Task
from .task_classification import Classification
from .task_next import Next
from .task_similarity import Similarity
from .task_generation import Generation
from .task_continuation import Continuation
from .task_unmasking import Unmasking
